# Engineering Write-up

## Atomic decision
PostgreSQL is the source of truth. Requested seats are sorted and locked with pessimistic write locks before their state is checked or changed. The reservation and seat updates occur in one transaction.

## User limit
A unique `(show_id,user_id)` booking-lock row is created with `ON CONFLICT DO NOTHING` and then locked. This serializes concurrent reservations by the same user for the same show before the limit is checked.

## Idempotency
The key is persisted with `(show_id,user_id,idempotency_key)` uniqueness and a normalized request hash. A retry returns the original reservation; the same key with different seats returns 409.

## Multi-seat behavior
All-or-nothing. If any requested seat is unavailable, no requested seat is confirmed.

## Consistency
The database is required for booking. During a database failure the service fails closed rather than risking duplicate sales.

## Observability
Actuator health and Prometheus metrics are included. Production deployment should add centralized structured logs, tracing, alerting and request correlation.

## AI usage
AI was used for scaffolding, code drafting, documentation, test ideas and review. Concurrency decisions were explicitly reviewed around transaction boundaries, row locking, deterministic ordering and idempotency constraints.
