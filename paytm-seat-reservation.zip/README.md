# Paytm Money - Seat Reservation at Scale

Java 17 / Spring Boot / PostgreSQL / Flyway / Apache Tomcat 10.1.

## Run
```bash
docker compose up --build
```

Base URL:
`http://localhost:8080/seat-reservation`

Create show:
```bash
curl -X POST http://localhost:8080/seat-reservation/shows -H 'Content-Type: application/json' -d '{"name":"friday-night","seats":["A1","A2","A3","A4"],"pricePaise":25000,"perUserLimit":4}'
```

Reserve:
```bash
curl -X POST http://localhost:8080/seat-reservation/shows/<SHOW_ID>/reserve -H 'Content-Type: application/json' -H 'Authorization: Bearer user-1' -d '{"seats":["A1"],"idempotencyKey":"booking-001"}'
```

State:
`GET /seat-reservation/shows/<SHOW_ID>`

Health:
`/seat-reservation/health/live`
`/seat-reservation/health/ready`

Metrics:
`/seat-reservation/actuator/prometheus`

Build WAR:
```bash
mvn clean package
```
Deploy `target/seat-reservation.war` to Tomcat 10.1 `webapps/`.

The reservation model is all-or-nothing for multi-seat requests. PostgreSQL row locks protect hot seats; a `(show_id,user_id)` booking lock serializes concurrent bookings for one user. Money is integer paise.

AI was used for scaffolding, code drafting, documentation and concurrency review. This is an independent interview exercise, not official Paytm code.
