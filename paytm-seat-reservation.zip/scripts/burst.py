#!/usr/bin/env python3
import concurrent.futures,json,sys,uuid,urllib.request,urllib.error
BASE=sys.argv[1].rstrip("/") if len(sys.argv)>1 else "http://localhost:8080/seat-reservation"
SHOW=sys.argv[2] if len(sys.argv)>2 else ""
N=int(sys.argv[3]) if len(sys.argv)>3 else 500
if not SHOW:
 print("Usage: python scripts/burst.py <BASE_URL> <SHOW_ID> [N]");sys.exit(1)
def call(i):
 data=json.dumps({"seats":["A1"],"idempotencyKey":str(uuid.uuid4())}).encode()
 req=urllib.request.Request(f"{BASE}/shows/{SHOW}/reserve",data=data,headers={"Content-Type":"application/json","Authorization":f"Bearer user-{i}"},method="POST")
 try:
  with urllib.request.urlopen(req,timeout=30) as r:return r.status
 except urllib.error.HTTPError as e:return e.code
 except Exception:return 599
with concurrent.futures.ThreadPoolExecutor(max_workers=min(200,N)) as ex:
 results=list(ex.map(call,range(N)))
from collections import Counter
print(Counter(results))
print("Expected hot-seat result: exactly one 201; remaining requests 409.")
