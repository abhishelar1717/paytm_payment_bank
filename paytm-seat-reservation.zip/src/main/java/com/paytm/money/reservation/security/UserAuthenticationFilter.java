package com.paytm.money.reservation.security;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;

@Component
public class UserAuthenticationFilter extends OncePerRequestFilter{
 protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  String p=req.getRequestURI();
  if(p.contains("/health/")||p.contains("/actuator/")){chain.doFilter(req,res);return;}
  String a=req.getHeader("Authorization");
  if(a==null||!a.startsWith("Bearer ")||a.substring(7).isBlank()){res.setStatus(401);res.setContentType("application/json");res.getWriter().write("{"error":"UNAUTHORIZED"}");return;}
  req.setAttribute("userId",a.substring(7).trim());chain.doFilter(req,res);
 }
}
