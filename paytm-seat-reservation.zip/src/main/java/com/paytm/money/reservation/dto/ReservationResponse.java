package com.paytm.money.reservation.dto;
import com.paytm.money.reservation.enums.ReservationStatus;
import java.util.*;
public record ReservationResponse(UUID reservationId,UUID showId,String userId,List<String> seats,long amountPaise,ReservationStatus status){}
