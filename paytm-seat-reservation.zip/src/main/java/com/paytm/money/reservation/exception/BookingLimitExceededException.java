package com.paytm.money.reservation.exception;
public class BookingLimitExceededException extends RuntimeException{public BookingLimitExceededException(int l){super("Per-user booking limit exceeded. Limit: "+l);}}
