package com.paytm.money.reservation.enums;
public enum SeatStatus { AVAILABLE, HELD, CONFIRMED }
