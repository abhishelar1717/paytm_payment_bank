package com.paytm.money.reservation.repository;
import com.paytm.money.reservation.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;
public interface ReservationRepository extends JpaRepository<Reservation,UUID>{}
