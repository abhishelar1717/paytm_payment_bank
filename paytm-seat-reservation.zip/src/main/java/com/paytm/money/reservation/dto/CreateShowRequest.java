package com.paytm.money.reservation.dto;
import jakarta.validation.constraints.*;
import java.util.List;
public record CreateShowRequest(@NotBlank String name,@NotEmpty List<@NotBlank String> seats,@Min(1) long pricePaise,@Min(1) Integer perUserLimit){}
