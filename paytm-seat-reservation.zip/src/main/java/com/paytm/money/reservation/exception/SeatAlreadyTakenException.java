package com.paytm.money.reservation.exception;
public class SeatAlreadyTakenException extends RuntimeException{public SeatAlreadyTakenException(String s){super("Seat already taken: "+s);}}
