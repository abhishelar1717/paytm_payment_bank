package com.paytm.money.reservation.config;
import com.paytm.money.reservation.security.UserAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.*;
@Configuration @RequiredArgsConstructor
public class SecurityConfig{
 private final UserAuthenticationFilter filter;
 @Bean SecurityFilterChain security(HttpSecurity http)throws Exception{
  return http.csrf(c->c.disable()).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
   .authorizeHttpRequests(a->a.anyRequest().permitAll())
   .addFilterBefore(filter,org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class).build();
 }
}
