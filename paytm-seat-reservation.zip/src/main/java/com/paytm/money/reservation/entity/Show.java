package com.paytm.money.reservation.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.*;

@Entity @Table(name="shows")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Show {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @Column(nullable=false) private String name;
 @Column(name="price_paise",nullable=false) private long pricePaise;
 @Column(name="per_user_limit",nullable=false) private int perUserLimit;
 @Column(name="created_at",nullable=false) private LocalDateTime createdAt;
 @OneToMany(mappedBy="show",cascade=CascadeType.ALL,orphanRemoval=true)
 @Builder.Default private List<Seat> seats=new ArrayList<>();
 @PrePersist void prePersist(){createdAt=LocalDateTime.now();if(perUserLimit<=0)perUserLimit=4;}
}
