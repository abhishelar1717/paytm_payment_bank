package com.paytm.money.reservation.exception;
public class IdempotencyConflictException extends RuntimeException{public IdempotencyConflictException(){super("Same idempotency key was used with a different request.");}}
