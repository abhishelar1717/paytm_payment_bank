package com.paytm.money.reservation.metrics;
import io.micrometer.core.instrument.*;
import org.springframework.stereotype.Component;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class ReservationMetrics{
 private final Counter confirmed,seatTaken,userLimit,replay;
 private final AtomicInteger available=new AtomicInteger();
 public ReservationMetrics(MeterRegistry r){
  confirmed=Counter.builder("reservations_confirmed_total").register(r);
  seatTaken=Counter.builder("reservations_declined_total").tag("reason","seat_taken").register(r);
  userLimit=Counter.builder("reservations_declined_total").tag("reason","per_user_limit").register(r);
  replay=Counter.builder("reservations_declined_total").tag("reason","idempotent_replay").register(r);
  Gauge.builder("seats_available",available,AtomicInteger::get).register(r);
 }
 public void confirmed(){confirmed.increment();} public void seatTaken(){seatTaken.increment();}
 public void userLimit(){userLimit.increment();} public void replay(){replay.increment();}
 public void available(long n){available.set((int)n);}
}
