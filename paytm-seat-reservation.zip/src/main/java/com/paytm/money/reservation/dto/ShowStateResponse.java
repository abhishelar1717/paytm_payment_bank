package com.paytm.money.reservation.dto;
import java.util.*;
public record ShowStateResponse(UUID showId,String name,int totalSeats,long available,long held,long confirmed,List<SeatState> seats){
 public boolean invariantHolds(){return available+held+confirmed==totalSeats;}
}
