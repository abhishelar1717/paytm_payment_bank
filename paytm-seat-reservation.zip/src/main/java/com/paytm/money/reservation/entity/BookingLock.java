package com.paytm.money.reservation.entity;
import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;

@Entity @Table(name="booking_locks",uniqueConstraints=@UniqueConstraint(name="uk_booking_lock",columnNames={"show_id","user_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BookingLock {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @Column(name="show_id",nullable=false) private UUID showId;
 @Column(name="user_id",nullable=false) private String userId;
}
