package com.paytm.money.reservation.dto;
import com.paytm.money.reservation.enums.SeatStatus;
public record SeatState(String seat,SeatStatus status){}
