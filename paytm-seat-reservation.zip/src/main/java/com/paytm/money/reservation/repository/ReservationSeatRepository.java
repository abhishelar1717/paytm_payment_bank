package com.paytm.money.reservation.repository;
import com.paytm.money.reservation.entity.ReservationSeat;
import com.paytm.money.reservation.enums.ReservationStatus;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.UUID;
public interface ReservationSeatRepository extends JpaRepository<ReservationSeat,UUID>{
 @Query("select count(rs) from ReservationSeat rs where rs.reservation.show.id=:showId and rs.reservation.userId=:userId and rs.reservation.status=:status")
 long countUserSeats(@Param("showId")UUID showId,@Param("userId")String userId,@Param("status")ReservationStatus status);
}
