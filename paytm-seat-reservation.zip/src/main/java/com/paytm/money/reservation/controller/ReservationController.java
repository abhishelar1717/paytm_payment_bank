package com.paytm.money.reservation.controller;
import com.paytm.money.reservation.dto.*;
import com.paytm.money.reservation.service.ReservationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController @RequiredArgsConstructor
public class ReservationController{
 private final ReservationService service;
 @PostMapping("/shows/{showId}/reserve") @ResponseStatus(HttpStatus.CREATED)
 public ReservationResponse reserve(@PathVariable UUID showId,@RequestAttribute("userId") String userId,@Valid @RequestBody ReserveRequest r){
  return service.reserve(showId,userId,r);
 }
}
