package com.paytm.money.reservation.service;
import com.paytm.money.reservation.dto.*;
import com.paytm.money.reservation.entity.*;
import com.paytm.money.reservation.enums.SeatStatus;
import com.paytm.money.reservation.exception.ResourceNotFoundException;
import com.paytm.money.reservation.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service @RequiredArgsConstructor
public class ShowService{
 private final ShowRepository shows; private final SeatRepository seats;
 @Transactional public Show create(CreateShowRequest r){
  Show s=Show.builder().name(r.name()).pricePaise(r.pricePaise()).perUserLimit(r.perUserLimit()==null?4:r.perUserLimit()).build();
  Set<String> seen=new HashSet<>();
  for(String n:r.seats()){if(!seen.add(n))throw new IllegalArgumentException("Duplicate seat: "+n);s.getSeats().add(Seat.builder().show(s).seatNumber(n).status(SeatStatus.AVAILABLE).build());}
  return shows.save(s);
 }
 @Transactional(readOnly=true) public ShowStateResponse state(UUID id){
  Show s=shows.findById(id).orElseThrow(()->new ResourceNotFoundException("Show not found: "+id));
  List<Seat> list=seats.findByShowIdOrderBySeatNumber(id);
  long a=list.stream().filter(x->x.getStatus()==SeatStatus.AVAILABLE).count();
  long h=list.stream().filter(x->x.getStatus()==SeatStatus.HELD).count();
  long c=list.stream().filter(x->x.getStatus()==SeatStatus.CONFIRMED).count();
  return new ShowStateResponse(id,s.getName(),list.size(),a,h,c,list.stream().map(x->new SeatState(x.getSeatNumber(),x.getStatus())).toList());
 }
}
