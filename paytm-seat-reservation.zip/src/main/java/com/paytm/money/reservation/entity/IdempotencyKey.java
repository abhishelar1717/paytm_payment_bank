package com.paytm.money.reservation.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity @Table(name="idempotency_keys",uniqueConstraints=@UniqueConstraint(name="uk_idempotency",columnNames={"show_id","user_id","idempotency_key"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class IdempotencyKey {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @Column(name="show_id",nullable=false) private UUID showId;
 @Column(name="user_id",nullable=false) private String userId;
 @Column(name="idempotency_key",nullable=false) private String idempotencyKey;
 @Column(name="request_hash",nullable=false) private String requestHash;
 @Column(name="reservation_id",nullable=false) private UUID reservationId;
 @Column(name="created_at",nullable=false) private LocalDateTime createdAt;
 @PrePersist void prePersist(){createdAt=LocalDateTime.now();}
}
