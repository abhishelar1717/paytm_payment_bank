package com.paytm.money.reservation.entity;
import com.paytm.money.reservation.enums.SeatStatus;
import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;

@Entity @Table(name="seats",uniqueConstraints=@UniqueConstraint(name="uk_show_seat",columnNames={"show_id","seat_number"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Seat {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="show_id",nullable=false) private Show show;
 @Column(name="seat_number",nullable=false) private String seatNumber;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private SeatStatus status;
 @Column(name="reservation_id") private UUID reservationId;
 @Column(name="user_id") private String userId;
}
