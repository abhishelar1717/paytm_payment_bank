package com.paytm.money.reservation.exception;
public class ResourceNotFoundException extends RuntimeException{public ResourceNotFoundException(String m){super(m);}}
