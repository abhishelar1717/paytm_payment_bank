package com.paytm.money.reservation.entity;
import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;

@Entity @Table(name="reservation_seats")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ReservationSeat {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="reservation_id",nullable=false) private Reservation reservation;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="seat_id",nullable=false) private Seat seat;
}
