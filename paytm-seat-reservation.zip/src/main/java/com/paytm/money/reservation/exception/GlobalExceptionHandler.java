package com.paytm.money.reservation.exception;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import java.time.OffsetDateTime;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler{
 @ExceptionHandler(SeatAlreadyTakenException.class) ResponseEntity<?> a(SeatAlreadyTakenException e){return c("SEAT_TAKEN",e.getMessage());}
 @ExceptionHandler(BookingLimitExceededException.class) ResponseEntity<?> b(BookingLimitExceededException e){return c("PER_USER_LIMIT",e.getMessage());}
 @ExceptionHandler(IdempotencyConflictException.class) ResponseEntity<?> d(IdempotencyConflictException e){return c("IDEMPOTENCY_CONFLICT",e.getMessage());}
 @ExceptionHandler(ResourceNotFoundException.class) ResponseEntity<?> n(ResourceNotFoundException e){return ResponseEntity.status(404).body(body("NOT_FOUND",e.getMessage()));}
 @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<?> v(MethodArgumentNotValidException e){return ResponseEntity.badRequest().body(body("VALIDATION_ERROR","Invalid request"));}
 private ResponseEntity<?> c(String code,String msg){return ResponseEntity.status(409).body(body(code,msg));}
 private Map<String,Object> body(String code,String msg){return Map.of("timestamp",OffsetDateTime.now(),"error",code,"message",msg);}
}
