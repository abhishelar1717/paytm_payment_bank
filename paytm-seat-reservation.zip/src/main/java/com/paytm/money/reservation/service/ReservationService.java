package com.paytm.money.reservation.service;
import com.paytm.money.reservation.dto.*;
import com.paytm.money.reservation.entity.*;
import com.paytm.money.reservation.enums.*;
import com.paytm.money.reservation.exception.*;
import com.paytm.money.reservation.metrics.ReservationMetrics;
import com.paytm.money.reservation.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

@Service @RequiredArgsConstructor
public class ReservationService{
 private final ShowRepository shows; private final SeatRepository seats; private final ReservationRepository reservations;
 private final ReservationSeatRepository reservationSeats; private final IdempotencyKeyRepository keys;
 private final BookingLockRepository locks; private final ReservationMetrics metrics;

 @Transactional
 public ReservationResponse reserve(UUID showId,String userId,ReserveRequest r){
  Show show=shows.findById(showId).orElseThrow(()->new ResourceNotFoundException("Show not found: "+showId));
  List<String> wanted=r.seats().stream().distinct().sorted().toList();
  String hash=hash(wanted);

  Optional<IdempotencyKey> old=keys.findByShowIdAndUserIdAndIdempotencyKey(showId,userId,r.idempotencyKey());
  if(old.isPresent()){
   if(!old.get().getRequestHash().equals(hash))throw new IdempotencyConflictException();
   metrics.replay();
   return response(reservations.findById(old.get().getReservationId()).orElseThrow());
  }

  locks.createIfMissing(showId,userId);
  locks.findForUpdate(showId,userId).orElseThrow(()->new IllegalStateException("Booking lock unavailable"));

  long current=reservationSeats.countUserSeats(showId,userId,ReservationStatus.CONFIRMED);
  if(current+wanted.size()>show.getPerUserLimit()){metrics.userLimit();throw new BookingLimitExceededException(show.getPerUserLimit());}

  List<Seat> locked=new ArrayList<>();
  for(String n:wanted){
   Seat seat=seats.findForUpdate(showId,n).orElseThrow(()->new ResourceNotFoundException("Seat not found: "+n));
   if(seat.getStatus()!=SeatStatus.AVAILABLE){metrics.seatTaken();throw new SeatAlreadyTakenException(n);}
   locked.add(seat);
  }

  Reservation res=reservations.save(Reservation.builder().show(show).userId(userId)
    .amountPaise(Math.multiplyExact(show.getPricePaise(),wanted.size()))
    .status(ReservationStatus.CONFIRMED).build());

  for(Seat seat:locked){
   seat.setStatus(SeatStatus.CONFIRMED); seat.setReservationId(res.getId()); seat.setUserId(userId);
   res.getSeats().add(ReservationSeat.builder().reservation(res).seat(seat).build());
  }

  keys.save(IdempotencyKey.builder().showId(showId).userId(userId).idempotencyKey(r.idempotencyKey())
    .requestHash(hash).reservationId(res.getId()).build());
  metrics.confirmed();
  metrics.available(seats.findByShowIdOrderBySeatNumber(showId).stream().filter(x->x.getStatus()==SeatStatus.AVAILABLE).count());
  return response(res);
 }

 private String hash(List<String> s){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(String.join(",",s).getBytes(StandardCharsets.UTF_8)));}catch(Exception e){throw new IllegalStateException(e);}}
 private ReservationResponse response(Reservation r){return new ReservationResponse(r.getId(),r.getShow().getId(),r.getUserId(),r.getSeats().stream().map(x->x.getSeat().getSeatNumber()).sorted().toList(),r.getAmountPaise(),r.getStatus());}
}
