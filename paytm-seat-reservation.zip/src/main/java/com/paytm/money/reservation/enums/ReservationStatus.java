package com.paytm.money.reservation.enums;
public enum ReservationStatus { CONFIRMED, CANCELLED }
