package com.paytm.money.reservation.controller;
import com.paytm.money.reservation.dto.*;
import com.paytm.money.reservation.entity.Show;
import com.paytm.money.reservation.service.ShowService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController @RequestMapping("/shows") @RequiredArgsConstructor
public class ShowController{
 private final ShowService service;
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Show create(@Valid @RequestBody CreateShowRequest r){return service.create(r);}
 @GetMapping("/{showId}") public ShowStateResponse state(@PathVariable UUID showId){return service.state(showId);}
}
