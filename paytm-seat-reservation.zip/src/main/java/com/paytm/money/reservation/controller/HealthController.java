package com.paytm.money.reservation.controller;
import javax.sql.DataSource;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.sql.Connection;
import java.util.Map;

@RestController @RequestMapping("/health") @RequiredArgsConstructor
public class HealthController{
 private final DataSource ds;
 @GetMapping("/live") public Map<String,String> live(){return Map.of("status","UP");}
 @GetMapping("/ready") public ResponseEntity<?> ready(){
  try(Connection c=ds.getConnection()){if(c.isValid(2))return ResponseEntity.ok(Map.of("status","READY","database","UP"));}catch(Exception ignored){}
  return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of("status","NOT_READY","database","DOWN"));
 }
}
