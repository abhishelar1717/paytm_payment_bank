package com.paytm.money.reservation.repository;
import com.paytm.money.reservation.entity.IdempotencyKey;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface IdempotencyKeyRepository extends JpaRepository<IdempotencyKey,UUID>{
 Optional<IdempotencyKey> findByShowIdAndUserIdAndIdempotencyKey(UUID showId,String userId,String key);
}
