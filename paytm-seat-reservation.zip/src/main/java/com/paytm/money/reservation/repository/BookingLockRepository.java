package com.paytm.money.reservation.repository;
import com.paytm.money.reservation.entity.BookingLock;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;
public interface BookingLockRepository extends JpaRepository<BookingLock,UUID>{
 @Modifying
 @Query(value="insert into booking_locks(show_id,user_id) values (:showId,:userId) on conflict (show_id,user_id) do nothing",nativeQuery=true)
 int createIfMissing(@Param("showId")UUID showId,@Param("userId")String userId);
 @Lock(LockModeType.PESSIMISTIC_WRITE)
 @Query("select b from BookingLock b where b.showId=:showId and b.userId=:userId")
 Optional<BookingLock> findForUpdate(@Param("showId")UUID showId,@Param("userId")String userId);
}
