package com.paytm.money.reservation.entity;
import com.paytm.money.reservation.enums.ReservationStatus;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.*;

@Entity @Table(name="reservations")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Reservation {
 @Id @GeneratedValue(strategy=GenerationType.UUID) private UUID id;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="show_id",nullable=false) private Show show;
 @Column(name="user_id",nullable=false) private String userId;
 @Column(name="amount_paise",nullable=false) private long amountPaise;
 @Enumerated(EnumType.STRING) @Column(nullable=false) private ReservationStatus status;
 @Column(name="created_at",nullable=false) private LocalDateTime createdAt;
 @Column(name="cancelled_at") private LocalDateTime cancelledAt;
 @OneToMany(mappedBy="reservation",cascade=CascadeType.ALL,orphanRemoval=true)
 @Builder.Default private List<ReservationSeat> seats=new ArrayList<>();
 @PrePersist void prePersist(){createdAt=LocalDateTime.now();}
}
