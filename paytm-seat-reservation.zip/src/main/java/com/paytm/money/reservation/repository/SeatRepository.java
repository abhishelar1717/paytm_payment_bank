package com.paytm.money.reservation.repository;
import com.paytm.money.reservation.entity.Seat;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;
public interface SeatRepository extends JpaRepository<Seat,UUID>{
 @Lock(LockModeType.PESSIMISTIC_WRITE)
 @Query("select s from Seat s where s.show.id=:showId and s.seatNumber=:seatNumber")
 Optional<Seat> findForUpdate(@Param("showId")UUID showId,@Param("seatNumber")String seatNumber);
 List<Seat> findByShowIdOrderBySeatNumber(UUID showId);
}
