package com.paytm.money.reservation;
import org.junit.jupiter.api.Test;
class SeatReservationApplicationTests { @Test void placeholder() {} }
